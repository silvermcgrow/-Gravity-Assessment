import React from 'react';

const TodoItem = ({ todo, toggleComplete, deleteTodo }) => {
  return (
    <li className={ todo.completed ? 'completed':'pending'}>
      <span onClick={() => toggleComplete(todo.id)}>{todo.todo}</span>
      <button onClick={() => deleteTodo(todo.id)}>Delete</button>
    </li>
  );
};

export default TodoItem;
